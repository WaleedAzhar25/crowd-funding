package com.example.crowd_funding

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
