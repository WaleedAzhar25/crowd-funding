import 'package:flutter/material.dart';

class AppColors{
  static Color primarycolor=Color(0xff00ADB5);
  static Color textcolour= Color(0xff5B6974);
  static Color hintcolour= Color(0xffB4B4B4);
  static Color textfieldbordercolor=Color(0xffE3E3E3);
  static Color textfeildiconcolor=Color(0xffD9D9D9);
  static Color hintstyleColor=Color(0xffC2C3CB);
// static Color
}
const defaultPadding = 16.0;
// const defaultBorderRadius = 12.0;
